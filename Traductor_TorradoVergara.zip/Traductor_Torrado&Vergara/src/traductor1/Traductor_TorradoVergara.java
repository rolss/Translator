/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traductor1;

/**
 *
 * @author Torrado'sLaptop
 */
public class Traductor_TorradoVergara {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Traductor ui = new Traductor();
        ui.setVisible(true);
        ui.setBounds(1200, 100, 385, 330);
    }
    
}
